package com.thinkful.fizzbuzzunit1;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;


public class MainActivity extends Activity {

    TextView textView;
    EditText editText;
    String fizz = "Fizz";
    String buzz = "Buzz";
    String fizzbuzz = "FizzBuzz";
    String valueString;

    int[] fizzArray = new int[10];
    int fizzIndex = 0;
    int[] buzzArray = new int[10];
    int buzzIndex = 0;
    int[] fizzBuzzArray = new int[10];
    int fizzBuzzIndex = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        int x = 5;
        int y = 6;

        Log.i("myData", "sumValue = " + myAdd(x,y));
        Log.i("myData", "subValue = " + mySubtract(x,y));
        Log.i("myData", "multValue = " + myMultiply(x,y));
        Log.i("myData", "divValue = " + myDivide(x,y));

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public int myAdd(int number1, int number2){
        int sum;
        sum = number1+number2;
        return sum;
    }

    public int mySubtract(int number1, int number2){
        int diff;
        diff = number1-number2;
        return diff;
    }

    public int myMultiply(int number1, int number2){
        int prod;
        prod = number1*number2;
        return prod;
    }

    public double myDivide(int number1, int number2){
        double quotient;
        quotient = (double) number1/number2;
        return quotient;
    }

    public String checkValue(int i){
        String val;
        if (i%3==0 && i%5==0){
            val = fizzbuzz;
            fizzBuzzArray[fizzBuzzIndex] = i;
            fizzBuzzIndex++;
        }
        else if (i%3==0){
            val = fizz;
            fizzArray[fizzIndex] = i;
            fizzIndex++;
        }
        else if (i%5==0){
            val = buzz;
            buzzArray[buzzIndex] = i;
            buzzIndex++;
        }
        else {
            val = String.valueOf(i);
        }
        return val;
    }

    public void doButton(View view){
        // Implement the function of the button here
        // Use numberOfValues, and create a string array of both the numbers and words,
        // replacing the appropriate numbers with the words fizz or buzz

        editText = (EditText) findViewById(R.id.editText); // user input
        textView = (TextView) findViewById(R.id.fizzText); // where the text will display
        textView.setText("" + "\n");

        int numberOfValues = Integer.parseInt(editText.getText().toString());

        for (int i=1;i<=numberOfValues;i++){
            valueString = checkValue(i);
            textView.append(valueString + "\n"); // display in the textView
        }
        for (int i=0;i<fizzArray.length;i++){
            Log.i("myData", "fizz["+i+"] =" + fizzArray[i]);
        }
        for (int i=0;i<buzzArray.length;i++){
            Log.i("myData", "buzz["+i+"] =" + buzzArray[i]);
        }
        for (int i=0;i<fizzBuzzArray.length;i++){
            Log.i("myData", "fizzBuzz["+i+"] =" + fizzBuzzArray[i]);
        }

    }
}
